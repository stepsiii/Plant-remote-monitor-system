package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;


import db.DBOper;
import model.Shuju;

public class Shujudao {
public List<Shuju> findbyday() {
		List<Shuju> shujuList = new ArrayList<Shuju>();
		
		try{
		
		DBOper db = new DBOper();
		// �������ݿ�
		Connection conn=db.getConn("localhost", "dh", "root", "root");
		String sql = "SELECT wen,shi,guang,hou FROM `zhiwu` WHERE year=? AND mon=? AND day=?;";// ��ѯcondition���з���Ҫ��ļ�¼
		//int rs = db.executeUpdate(sql, new String[] { id,date,tempe,pulse,blopre_h,blopre_l,blosug });// ִ�в�ѯ��username��userpass������������Ϊ����
		PreparedStatement pst = conn.prepareStatement(sql);
		
		SimpleDateFormat myfmt=new SimpleDateFormat("yyyy-MM-dd-HH");
		String[] shijian=myfmt.format(new java.util.Date()).split("-");
		
		pst.setInt(1, Integer.parseInt(shijian[0]));
		pst.setInt(2, Integer.parseInt(shijian[1]));
		pst.setInt(3, Integer.parseInt(shijian[2])-1);
		
		ResultSet rs = pst.executeQuery();
		
		
		while (rs.next()) {
			Shuju shuju = new Shuju();
			
			shuju.setWen(rs.getFloat("wen"));
			shuju.setShi(rs.getFloat("shi"));
			shuju.setGuang(rs.getFloat("guang"));
			shuju.setHou(rs.getInt("hou"));
			
			shujuList.add(shuju);
		}
		
		
		}catch (Exception e) {
			// TODO: handle exception
		}
		return shujuList;
	}
	

	public List<Shuju> findbymon() {
		
		List<Shuju> shujuList = new ArrayList<Shuju>();
		try {
		DBOper db = new DBOper();
		
		// �������ݿ�
		Connection conn=db.getConn("localhost", "dh", "root", "root");
		String sql = "SELECT wen,shi,guang,day FROM `zhiwu` WHERE year=? AND mon=? AND hou=?;";// ��ѯcondition���з���Ҫ��ļ�¼
		//int rs = db.executeUpdate(sql, new String[] { id,date,tempe,pulse,blopre_h,blopre_l,blosug });// ִ�в�ѯ��username��userpass������������Ϊ����
		PreparedStatement pst = conn.prepareStatement(sql);
		
		SimpleDateFormat myfmt=new SimpleDateFormat("yyyy-MM-dd-HH");
		String[] shijian=myfmt.format(new java.util.Date()).split("-");
		
		pst.setInt(1, Integer.parseInt(shijian[0]));
		pst.setInt(2, Integer.parseInt(shijian[1]));
		pst.setInt(3, 10);
		
		ResultSet rs = pst.executeQuery();
		
		while (rs.next()) {
			Shuju shuju = new Shuju();
			
			shuju.setWen(rs.getFloat("wen"));
			shuju.setShi(rs.getFloat("shi"));
			shuju.setGuang(rs.getFloat("guang"));
			shuju.setDay(rs.getInt("day"));
			
			shujuList.add(shuju);
		}
		}catch (Exception e) {
			// TODO: handle exception
		}
		return shujuList;
	}
	
	public List<Shuju> findbysec() {
		List<Shuju> shujuList = new ArrayList<Shuju>();
		
		try{
		
		DBOper db = new DBOper();
		// �������ݿ�
		Connection conn=db.getConn("localhost", "dh", "root", "root");
		String sql = "SELECT guang FROM `shishi` WHERE day=? AND hou=? AND min=?;";// ��ѯcondition���з���Ҫ��ļ�¼
		//int rs = db.executeUpdate(sql, new String[] { id,date,tempe,pulse,blopre_h,blopre_l,blosug });// ִ�в�ѯ��username��userpass������������Ϊ����
		PreparedStatement pst = conn.prepareStatement(sql);
		
		SimpleDateFormat myfmt=new SimpleDateFormat("yyyy-MM-dd-HH-mm");
		String[] shijian=myfmt.format(new java.util.Date()).split("-");
		
		pst.setInt(1, Integer.parseInt(shijian[2]));
		pst.setInt(2, Integer.parseInt(shijian[3]));
		pst.setInt(3, Integer.parseInt(shijian[4]));
		
		ResultSet rs = pst.executeQuery();
		
		
		while (rs.next()) {
			Shuju shuju = new Shuju();
			shuju.setGuang(rs.getFloat("guang"));
			
			shujuList.add(shuju);
		}
		
		
		}catch (Exception e) {
			// TODO: handle exception
		}
		return shujuList;
	}
	
}
