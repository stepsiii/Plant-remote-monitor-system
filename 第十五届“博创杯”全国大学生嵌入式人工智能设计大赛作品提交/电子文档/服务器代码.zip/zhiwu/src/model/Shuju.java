package model;

public class Shuju {
	float wen;
	float shi;
	float guang;
	int year;
	int mon;
	int day;
	int hou;
	public float getWen() {
		return wen;
	}
	public void setWen(float wen) {
		this.wen = wen;
	}
	public float getShi() {
		return shi;
	}
	public void setShi(float shi) {
		this.shi = shi;
	}
	public float getGuang() {
		return guang;
	}
	public void setGuang(float guang) {
		this.guang = guang;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getMon() {
		return mon;
	}
	public void setMon(int mon) {
		this.mon = mon;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public int getHou() {
		return hou;
	}
	public void setHou(int hou) {
		this.hou = hou;
	}
}
