package controler;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db.DBOper;

/**
 * Servlet implementation class Jieshouservlet
 */
@WebServlet("/Jieshouservlet")
public class Jieshouservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Jieshouservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		request.setCharacterEncoding("GBK");
		response.setContentType("text/html;charset=GBK");
		PrintWriter out = response.getWriter();
		
		String wen = request.getParameter("wen");
		String shi = request.getParameter("shi");
		String guang = request.getParameter("guang");
		SimpleDateFormat myfmt=new SimpleDateFormat("yyyy-MM-dd-HH");
		String[] shijian=myfmt.format(new java.util.Date()).split("-");
		
		System.out.println("�յ�����");
		ServletContext ctx = this.getServletContext();
		// ͨ��ServletContext���web.xml�����õĳ�ʼ������
		String server = ctx.getInitParameter("server");// ��ȡ��������ַ
		String dbname = ctx.getInitParameter("dbname");// ��ȡ���ݿ���
		String user = ctx.getInitParameter("user");// ��ȡ���ݿ��û���
		String pwd = ctx.getInitParameter("pwd");// ��ȡ���ݿ�����
		
		DBOper db = new DBOper();
		try {
			// �������ݿ�
			Connection conn=db.getConn(server, dbname, user, pwd);
			String sql = "insert into `zhiwu` values(?,?,?,?,?,?,?);";// ��ѯcondition���з���Ҫ��ļ�¼
			
			PreparedStatement pst = conn.prepareStatement(sql);
			
			//��SQLָ���еĲ������и�ֵ
			pst.setFloat(1, Float.parseFloat(wen));
			pst.setFloat(2, Float.parseFloat(shi));
			pst.setFloat(3, Float.parseFloat(guang));
			pst.setInt(4, Integer.parseInt(shijian[0]));
			pst.setInt(5, Integer.parseInt(shijian[1]));
			pst.setInt(6, Integer.parseInt(shijian[2]));
			pst.setInt(7, Integer.parseInt(shijian[3]));
			int rs = pst.executeUpdate();
			// �Ϸ����û�
			if (rs >0) {
				response.getWriter().append("Served at: ").append(request.getContextPath());
				System.out.println("���ӳɹ�");
			} else { // ���Ϸ����û�
				out.println("�ϴ�ʧ��");
				System.out.println("����ʧ��");
			}
		} catch (Exception e) {
			out.println("����ʧ��");
			System.out.println("��������");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
